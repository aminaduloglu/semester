/*
Вариант 30. Москва, КМПО РАНХиГС, 2022/2024
В базе данных лесного колледжа содержатся сведения об успеваемости студентов.
Структура входного файла in.txt (Студент Группа Дисциплина Оценки)
Тигра Г1 Физика 3.5
Винни_Пух Г2 Пчеловодство 5.0
Винни_Пух Г2 Русский_язык 3.0
Кролик Г1 Русский_язык 4.75
Тигра Г1 Химия 3.67

…
Сформировать список студентов с любимыми дисциплинами, исходя из среднего балла (гарантируется, что для
каждого студента только одна любимая дисциплина). Список упорядочить по названию группы и по фамилии студента
Структура выходного файла out.txt
Г1 Кролик Русский_язык
Г1 Тигра Химия
Г2 Винни_Пух Пчеловодство
*/

/* Этап 2. Получение списка любимых дисциплин. Анализируем сразу, при чтении файла.
Если очередной студент уже есть в списке, сравним средний балл из базы со средним баллом из списка, если требуется, заменим запись в списке.
Начало решения 20.03.2024, 15:22
Окончание решения 20.03.2024, 16:34
Время 01:12. Суммарное время 02:01 */




#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

#define COLLEDGE_SIZE 1000

typedef struct {
    char gr[20];
    char st[20];
    char disc[20];
    double mark;
} Record;

int compare(const void *a, const void *b) {
    Record *rec1 = (Record *)a;
    Record *rec2 = (Record *)b;

    int group_cmp = strcmp(rec1->gr, rec2->gr);
    if (group_cmp != 0) {
        return group_cmp;
    }

    return strcmp(rec1->st, rec2->st);
}

int main(void) {
    setlocale(LC_ALL, "");

    Record v[COLLEDGE_SIZE];

    FILE *in = fopen("in.txt", "r");
    int n = 0;
    Record rec;

    char smark[20];
    while (fscanf(in, "%s %s %s %s", rec.st, rec.gr, rec.disc, smark) == 4) {
        rec.mark = atof(smark);

        int found = 0;
        for (int i = 0; i < n; i++) {
            if (strcmp(v[i].st, rec.st) == 0) {
                if (rec.mark > v[i].mark) {
                    strcpy(v[i].disc, rec.disc);
                    v[i].mark = rec.mark;
                }
                found = 1;
                break;
            }
        }

        if (!found) {
            v[n] = rec;
            n++;
        }
    }
    fclose(in);

    qsort(v, n, sizeof(Record), compare);

    FILE *out = fopen("out.txt", "w");
    for (int i = 0; i < n; i++) {
        fprintf(out, "%s %s %s\n", v[i].gr, v[i].st, v[i].disc);
    }
    fclose(out);

    return 0;
}