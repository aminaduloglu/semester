#include <stdio.h>

// Функция для двоичного поиска в отсортированном массиве
int binarySearch(int arr[], int left, int right, int x) {
    while (left <= right) {
        int mid = left + (right - left) / 2;

        // Проверяем, находится ли x в середине
        if (arr[mid] == x)
            return mid;

        // Если x больше, чем значение в середине, игнорируем левую часть
        if (arr[mid] < x)
            left = mid + 1;

        // Если x меньше, чем значение в середине, игнорируем правую часть
        else
            right = mid - 1;
    }

    // Если x не найдено в массиве, возвращаем -1
    return -1;
}

int main() {
    FILE * fh = fopen("1.dat", "wb+");
    int x = 0;
    int search_number;
    long i;
    long isize = sizeof(int);
    long fsize;

    /// Запишем числа в файл
    for (i = 1; i <= 10; i++)
        fwrite(&i, isize, 1, fh);

    /// Определим число записей в файле
    fseek(fh, 0, SEEK_END);
    fsize = ftell(fh) / sizeof(int);

    /// Отпечатаем содержимое файла
    fseek(fh, 0, SEEK_SET);
    for (i = 0; i < fsize; i++) {
        fread(&x, isize, 1, fh);
        printf("%d ", x);
    }
    putchar('\n');

    /// Число, которое пользователь хочет найти в файле
    scanf("%d", &search_number);

    /// Прочитаем числа из файла в массив
    int numbers[fsize];
    fseek(fh, 0, SEEK_SET);
    for (i = 0; i < fsize; i++) {
        fread(&numbers[i], sizeof(int), 1, fh);
    }

    // Выполним двоичный поиск числа в отсортированном массиве
    int result = binarySearch(numbers, 0, fsize - 1, search_number);

    if (result != -1) {
        printf("%d найдено на позиции %d.\n", search_number, result);
    } else {
        printf("%d не найдено\n", search_number);
    }

    fclose(fh);
    return 0;
}
