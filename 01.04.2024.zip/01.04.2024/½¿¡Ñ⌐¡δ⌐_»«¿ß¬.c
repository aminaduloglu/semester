#include <stdio.h>

int main() {
    FILE * fh = fopen("1.dat", "wb+");
    int x = 0;
    long i;
    long isize = sizeof(int);
    long fsize;
    int search_number;
    int found = 0; // флаг для обозначения нахождения числа

    /// Запишем числа в файл
    for (i = 1; i <= 10; i++)
        fwrite(&i, isize, 1, fh);

    /// Определим число записей в файле
    fseek(fh, 0, SEEK_END);
    fsize = ftell(fh) / sizeof(int);

    /// Отпечатаем содержимое файла
    fseek(fh, 0, SEEK_SET);
    for (i = 0; i < fsize; i++) {
        fread(&x, isize, 1, fh);
        printf("%d ", x);
    }
    putchar('\n');

    /// Получим число, которое пользователь хочет найти в файле
    scanf("%d", &search_number);

    /// Линейный поиск числа в файле
    fseek(fh, 0, SEEK_SET);
    for (i = 0; i < fsize; i++) {
        fseek(fh, isize * i, SEEK_SET);
        fread(&x, isize, 1, fh);
        if (x == search_number) {
            printf("%d найдено на позиции %ld.\n", search_number, i);
            found = 1;
            break;
        }
    }

    /// Если число не найдено
    if (!found) {
        printf("%d не найдено\n", search_number);
    }

    /// Заменим нечетные числа на противоположные
    fseek(fh, 0, SEEK_SET);
    for (i = 0; i < fsize; i++) {
        fseek(fh, isize * i, SEEK_SET);
        fread(&x, isize, 1, fh);
        if (x % 2 != 0) {
            x = -x;
            fseek(fh, isize * i, SEEK_SET);
            fwrite(&x, isize, 1, fh);
        }
    }

    /// Отпечатаем содержимое файла
    fseek(fh, 0, SEEK_SET);
    for (i = 0; i < fsize; i++) {
        fread(&x, sizeof(int), 1, fh);
        printf("%d ", x);
    }
    putchar('\n');
    fclose(fh);
    return 0;
}
