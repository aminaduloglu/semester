/*В базе данных хранятся сведения о работе библиотеки: дата, читатель, название, автор
Структура входного файла in.txt (Дата Читатель Книга Автор)
15.05.2014	Винни-Пух Евгений Онегин	Пушкин
15.06.2014	Пятачок	Мастер и Маргарита	Булгаков
16.06.2014	Кенга Капитанская дочка	Пушкин
...
Определить: отсортированный по читателям список выдач книг Пушкина
Структура выходного файла out.txt
Читатель	Книга  Автор
Винни-Пух Евгений Онегин Пушкин
Кенга Капитанская дочка Пушкин
*/

#include <stdio.h>
#include <string.h>

#define COLLEGE_SIZE 1000

void print_out(char v[][50], int n) {
    FILE *out = fopen("out.txt", "w");
    if (out == NULL) {
        printf("Ошибка при открытии файла out.txt\n");
        return;
    }
    for (int i = 0; i < n; i++) {
        fprintf(out, "%s\n", v[i]);
    }
    fclose(out);
}

int main(void) {
    char v[COLLEGE_SIZE][50];

    FILE *in = fopen("in.txt", "r");
    if (in == NULL) {
        printf("Ошибка при открытии файла in.txt\n");
        return 1;
    }

    int n = 0;
    char author[50];

    while (fscanf(in,"%s",author)==1) {
           if (strcmp(author,"Пушкин") == 0 || strcmp(author,"Булгаков")==0) {
               strcpy(v[n],author);
               n++;
           }
    }
    fclose(in);

    print_out(v, n);

    return 0;
}

