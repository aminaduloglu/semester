/*
Вариант 8.
В базе данных хранятся сведения о работе библиотеки: дата, читатель, название, автор
Структура входных файлов 
reader.txt (id, дата, читатель)
1;15.05.2014; Винни-Пух 
2;15.06.2014;Пятачок	
3;16.06.2014;Кенга 

book.txt (id читателя,книга, автор)
1;Евгений Онегин;Пушкин
2;Мастер и Маргарита;Булгаков
3;Капитанская дочка;Пушкин

Определить: отсортированный по читателям список выдач книг Пушкина
Структура выходного файла out.txt
Читатель	Книга
Кенга Капитанская дочка
Винни-Пух Евгений Онегин
*/

/*
Начало решения 24.03.2024, 19:27
Окончание решения 24.03.2024, 20:39
Время 01:12 вместе с подготовкой файлов 
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 100
#define MAX_READERS 100
#define MAX_BOOKS 100

typedef struct {
    int reader_id;
    char book[MAX_LINE_LENGTH];
} BookIssue;

typedef struct {
    int id;
    char name[MAX_LINE_LENGTH];
} Reader;

typedef struct {
    int reader_id;
    char book[MAX_LINE_LENGTH];
    char author[MAX_LINE_LENGTH];
} Book;

int compareByReader(const void *a, const void *b) {
    return ((BookIssue *)a)->reader_id - ((BookIssue *)b)->reader_id;
}

int main() {
    FILE *reader_file = fopen("reader.txt", "r");
    FILE *book_file = fopen("book.txt", "r");

    if (reader_file == NULL || book_file == NULL) {
        perror("Ошибка при открытии файлов");
        return 1;
    }

    Reader readers[MAX_READERS];
    int reader_count = 0;

    char line[MAX_LINE_LENGTH];
    while (fgets(line, MAX_LINE_LENGTH, reader_file) != NULL && reader_count < MAX_READERS) {
        sscanf(line, "%d;%*[^;];%[^\n]", &readers[reader_count].id, readers[reader_count].name);
        reader_count++;
    }

    Book books[MAX_BOOKS];
    int book_count = 0;

    while (fgets(line, MAX_LINE_LENGTH, book_file) != NULL && book_count < MAX_BOOKS) {
        sscanf(line, "%d;%[^;];%[^\n]", &books[book_count].reader_id, books[book_count].book, books[book_count].author);
        book_count++;
    }

    printf("Читатель\tКнига\n");
    for (int i = 0; i < book_count; i++) {
        if (strstr(books[i].author, "Пушкин") != NULL) {
            for (int j = 0; j < reader_count; j++) {
                if (readers[j].id == books[i].reader_id) {
                    printf("%s\t%s\n", readers[j].name, books[i].book);
                    break;
                }
            }
        }
    }

    fclose(reader_file);
    fclose(book_file);

    return 0;
}
